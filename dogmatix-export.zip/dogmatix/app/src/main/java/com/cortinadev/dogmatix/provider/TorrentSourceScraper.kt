package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.data.service.TorrentFileIndexer
import com.cortinadev.dogmatix.data.service.TorrentMetadataFetcher
import com.cortinadev.dogmatix.util.FileParsingUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Scrapes torrent/magnet sources via libtorrent4j metadata fetching.
 * Produces [IndexedFile] results for each ROM file found in the torrent.
 * Downloads are handled by the existing TorrentDownloadService (libtorrent4j).
 */
class TorrentSourceScraper(
    private val metadataFetcher: TorrentMetadataFetcher,
    private val fileIndexer: TorrentFileIndexer
) : SourceScraper {

    override fun canHandle(url: String): Boolean =
        url.startsWith("magnet:") || url.endsWith(".torrent")

    override suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType,
        folders: List<String>,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult = withContext(Dispatchers.IO) {
        onProgress?.invoke("Fetching torrent metadata...")

        try {
            val info = metadataFetcher.fetch(url)
            val entries = fileIndexer.index(info, url, folders)

            if (entries.isEmpty()) {
                return@withContext ScrapeResult(emptyList(), listOf("No files found in torrent"))
            }

            val files = entries.map { entry ->
                val (cleanName, tagStrings) = FileParsingUtils.extractNameAndTags(entry.fileName)
                val extension = entry.fileName.substringAfterLast('.', "")
                    .let { if (it.isEmpty()) "" else ".$it" }

                IndexedFile(
                    name = cleanName,
                    fileName = entry.fileName,
                    downloadUrl = entry.torrentMagnet,
                    fileSize = entry.fileSize,
                    fileExtension = extension,
                    torrentFileIndex = entry.fileIndex,
                    torrentMagnet = entry.torrentMagnet,
                    tags = tagStrings + listOf(FileParsingUtils.normalizeTag(contentType.name))
                )
            }

            ScrapeResult(files)
        } catch (e: Exception) {
            ScrapeResult(emptyList(), listOf("Torrent metadata fetch failed: ${e.message}"))
        }
    }
}
