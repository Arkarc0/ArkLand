package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.util.FileParsingUtils
import com.cortinadev.dogmatix.util.JsonHttp
import com.cortinadev.dogmatix.util.ScrapingConstants
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Scrapes the Internet Archive using its metadata and search APIs.
 * Uses /advancedsearch.php for discovery and /metadata/{identifier} for file details.
 * Produces [IndexedFile] results with direct HTTPS download URLs.
 */
class ArchiveScraper : SourceScraper {

    override fun canHandle(url: String): Boolean =
        url.startsWith("https://archive.org/") || url.startsWith("http://archive.org/")

    override suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType,
        folders: List<String>,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult = withContext(Dispatchers.IO) {
        // If the URL points to a specific item, fetch its metadata directly
        val itemMatch = ITEM_URL_REGEX.find(url)
        if (itemMatch != null) {
            val identifier = itemMatch.groupValues[1]
            return@withContext scrapeItem(identifier, console.id, contentType, onProgress)
        }

        // Otherwise, search the Archive for software items
        scrapeSearch(url, console.id, contentType, onProgress)
    }

    /**
     * Fetches metadata for a single Archive item and produces IndexedFile results
     * for its downloadable ROM files.
     */
    private suspend fun scrapeItem(
        identifier: String,
        consoleId: String,
        contentType: ContentType,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult {
        onProgress?.invoke("Fetching Archive metadata for $identifier...")

        try {
            val metaUrl = "$IA_BASE/metadata/$identifier"
            val response = JsonHttp.request("GET", metaUrl)
            if (!response.ok) {
                return ScrapeResult(emptyList(), listOf("Archive metadata request failed: ${response.code}"))
            }

            val json = response.json?.asJsonObject
                ?: return ScrapeResult(emptyList(), listOf("Archive returned no JSON for $identifier"))

            val metadata = json.getAsJsonObject("metadata") ?: JsonObject()
            val files = json.getAsJsonArray("files") ?: return ScrapeResult(emptyList())

            val title = metadata.str("title").ifEmpty { identifier }
            val year = metadata.str("year")

            val romFiles = files.mapNotNull { element ->
                val file = element.asJsonObject ?: return@mapNotNull null
                val name = file.str("name")
                val size = file.get("size")?.takeIf { !it.isJsonNull }?.asLong ?: 0L
                val format = file.str("format")
                val source = file.str("source")

                // Only include original software files, skip metadata/thumbs/reviews
                if (source != "original") return@mapNotNull null
                if (name.isBlank() || name.startsWith("_")) return@mapNotNull null
                if (name.endsWith(".xml") || name.endsWith(".sqlite") || name.endsWith(".torrent")) return@mapNotNull null
                if (size == 0L) return@mapNotNull null

                // Check if it looks like a ROM file
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext !in ROM_EXTENSIONS) return@mapNotNull null

                val downloadUrl = "$IA_BASE/download/$identifier/${java.net.URLEncoder.encode(name, "UTF-8").replace("+", "%20")}"
                val (cleanName, tagStrings) = FileParsingUtils.extractNameAndTags(name.substringBeforeLast('.'))

                IndexedFile(
                    name = cleanName.ifBlank { title },
                    fileName = name,
                    downloadUrl = downloadUrl,
                    fileSize = size,
                    fileExtension = ".$ext",
                    tags = tagStrings + listOf(FileParsingUtils.normalizeTag(contentType.name))
                )
            }

            return if (romFiles.isNotEmpty()) {
                ScrapeResult(romFiles)
            } else {
                ScrapeResult(emptyList(), listOf("No ROM files found in $identifier"))
            }
        } catch (e: Exception) {
            return ScrapeResult(emptyList(), listOf("Archive item fetch failed: ${e.message}"))
        }
    }

    /**
     * Searches the Archive's advanced search API for software items and scrapes each one.
     */
    private suspend fun scrapeSearch(
        query: String,
        consoleId: String,
        contentType: ContentType,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult {
        onProgress?.invoke("Searching Internet Archive...")

        try {
            val searchQuery = "mediatype:software AND ($query)"
            val params = listOf(
                "q" to searchQuery,
                "fl[]" to "identifier,title,description,year,collection,item_size",
                "sort[]" to "downloads desc",
                "rows" to "20",
                "page" to "1",
                "output" to "json"
            )
            val queryString = params.joinToString("&") { "${it.first}=${java.net.URLEncoder.encode(it.second, "UTF-8")}" }
            val searchUrl = "$IA_BASE/advancedsearch.php?$queryString"

            val response = JsonHttp.request("GET", searchUrl)
            if (!response.ok) {
                return ScrapeResult(emptyList(), listOf("Archive search failed: ${response.code}"))
            }

            val json = response.json?.asJsonObject
                ?: return ScrapeResult(emptyList(), listOf("Archive search returned no JSON"))

            val docs = json.getAsJsonObject("response")?.getAsJsonArray("docs")
                ?: return ScrapeResult(emptyList(), listOf("Archive search returned no results"))

            val allFiles = mutableListOf<IndexedFile>()
            val allErrors = mutableListOf<String>()

            for (doc in docs) {
                val docObj = doc.asJsonObject ?: continue
                val identifier = docObj.str("identifier")
                if (identifier.isBlank()) continue

                delay(ScrapingConstants.REQUEST_DELAY_MS)
                val itemResult = scrapeItem(identifier, consoleId, contentType, onProgress)
                allFiles.addAll(itemResult.files)
                allErrors.addAll(itemResult.errors)
            }

            return ScrapeResult(allFiles, allErrors)
        } catch (e: Exception) {
            return ScrapeResult(emptyList(), listOf("Archive search failed: ${e.message}"))
        }
    }

    companion object {
        private const val IA_BASE = "https://archive.org"
        private val ITEM_URL_REGEX = Regex("archive\\.org/details/([\\w.-]+)")
        private val ROM_EXTENSIONS = setOf(
            "zip", "7z", "rar", "iso", "bin", "cue", "chd",
            "nes", "sfc", "smc", "gb", "gbc", "gba", "n64", "z64",
            "nds", "cia", "3ds", "md", "gen", "sms", "gg",
            "d64", "adf", "xci", "nsp", "rvz", "wbfs", "pbp", "cso",
            "lnx", "a26", "pce", "ngc", "ws", "wsc", "ngp", "ngpc",
            "jag", "vb", "lynx", "o2"
        )
    }

    private fun JsonObject.str(key: String): String =
        get(key)?.takeIf { !it.isJsonNull }?.asString?.trim() ?: ""
}
