package com.cortinadev.dogmatix.data.model

data class Manufacturer(
    val id: String,
    val name: String,
    val consoles: List<Console> = emptyList()
)

data class Console(
    val id: String,
    val name: String,
    val urls: List<UrlEntry> = emptyList(),
    /** Configured chip label; empty = built-in default. */
    val shortName: String = "",
    /** Configured download-folder aliases; empty = built-in defaults. */
    val folderAliases: List<String> = emptyList()
) {
    /** Source endpoints for this console, with provider identity. Populated from SourceEndpointEntity. */
    var endpoints: List<SourceEndpoint> = emptyList()
}

/**
 * A concrete source endpoint with a stable provider identity.
 * Distinct from [UrlEntry] which is the legacy raw-URL form.
 */
data class SourceEndpoint(
    val providerId: String,
    val url: String,
    val contentType: ContentType = ContentType.GAME,
    val folders: List<String> = emptyList(),
    val enabled: Boolean = true
)
