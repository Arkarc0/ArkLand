package com.cortinadev.dogmatix.provider

import android.util.Log
import com.cortinadev.dogmatix.data.local.dao.ProviderDao
import com.cortinadev.dogmatix.data.local.dao.SourceEndpointDao
import com.cortinadev.dogmatix.data.local.entity.ProviderEntity
import com.cortinadev.dogmatix.data.local.entity.SourceEndpointEntity
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.data.model.ContentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "UnifiedSearchService"
private const val PROVIDER_TIMEOUT_MS = 15_000L

/**
 * Queries multiple enabled providers in parallel and aggregates results.
 * Each provider runs independently — if one fails, others continue.
 */
@Singleton
class UnifiedSearchService @Inject constructor(
    private val providerRegistry: ProviderRegistry,
    private val providerDao: ProviderDao,
    private val sourceEndpointDao: SourceEndpointDao,
    private val deduplicationService: DeduplicationService
) {

    /**
     * Search across all enabled providers for a given console.
     * Returns deduplicated results with source information.
     */
    suspend fun searchAcrossProviders(
        consoleId: String,
        console: Console,
        onProgress: ((String) -> Unit)? = null
    ): SearchResult = withContext(Dispatchers.IO) {
        val enabledProviders = providerDao.getEnabledProviders()
        if (enabledProviders.isEmpty()) {
            return@withContext SearchResult(
                results = emptyList(),
                providerStatuses = emptyList(),
                tookMs = 0
            )
        }

        val startTime = System.currentTimeMillis()
        val providerStatuses = mutableListOf<ProviderStatus>()
        val allFiles = mutableListOf<IndexedFile>()

        // Query each provider in parallel
        coroutineScope {
            val jobs = enabledProviders.map { provider ->
                async {
                    searchProvider(provider, consoleId, console, onProgress)
                }
            }
            val results = jobs.awaitAll()
            for (result in results) {
                providerStatuses.add(result.status)
                allFiles.addAll(result.files)
            }
        }

        // Deduplicate across providers
        val merged = deduplicationService.deduplicate(allFiles)
        val tookMs = System.currentTimeMillis() - startTime

        Log.d(TAG, "Search across ${enabledProviders.size} providers: ${allFiles.size} files, ${merged.size} unique, ${tookMs}ms")

        SearchResult(
            results = merged,
            providerStatuses = providerStatuses,
            tookMs = tookMs
        )
    }

    private suspend fun searchProvider(
        provider: ProviderEntity,
        consoleId: String,
        console: Console,
        onProgress: ((String) -> Unit)?
    ): UnifiedProviderSearchResult {
        val startTime = System.currentTimeMillis()

        try {
            val endpoints = sourceEndpointDao.getEndpointsByProvider(provider.id)
                .filter { it.consoleId == consoleId }

            if (endpoints.isEmpty()) {
                return UnifiedProviderSearchResult(
                    status = ProviderStatus(provider.id, true, 0, null, 0),
                    files = emptyList()
                )
            }

            val scraper = providerRegistry.findScraper(endpoints.first().url)
                ?: return UnifiedProviderSearchResult(
                    status = ProviderStatus(provider.id, false, 0, "No scraper for ${provider.id}", System.currentTimeMillis() - startTime),
                    files = emptyList()
                )

            val allFiles = mutableListOf<IndexedFile>()
            for (endpoint in endpoints) {
                if (!endpoint.enabled) continue
                val result = withTimeoutOrNull(PROVIDER_TIMEOUT_MS) {
                    scraper.scrape(
                        url = endpoint.url,
                        console = console,
                        contentType = ContentType.valueOf(endpoint.contentType),
                        folders = emptyList(),
                        onProgress = onProgress
                    )
                } ?: continue
                // Tag files with provider ID for deduplication
                val taggedFiles = result.files.map { file ->
                    file.copy(tags = file.tags + "provider:${provider.id}")
                }
                allFiles.addAll(taggedFiles)
            }

            return UnifiedProviderSearchResult(
                status = ProviderStatus(provider.id, true, allFiles.size, null, System.currentTimeMillis() - startTime),
                files = allFiles
            )
        } catch (e: Exception) {
            Log.e(TAG, "Provider ${provider.id} search failed: ${e.message}")
            return UnifiedProviderSearchResult(
                status = ProviderStatus(provider.id, false, 0, e.message, System.currentTimeMillis() - startTime),
                files = emptyList()
            )
        }
    }
}

data class SearchResult(
    val results: List<MergedResult>,
    val providerStatuses: List<ProviderStatus>,
    val tookMs: Long
)

data class UnifiedProviderSearchResult(
    val status: ProviderStatus,
    val files: List<IndexedFile>
)

data class ProviderStatus(
    val providerId: String,
    val ok: Boolean,
    val count: Int,
    val error: String?,
    val tookMs: Long
)
