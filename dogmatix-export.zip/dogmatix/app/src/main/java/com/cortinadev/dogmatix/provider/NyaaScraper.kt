package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.util.FileParsingUtils
import com.cortinadev.dogmatix.util.HttpHeadersUtils
import com.cortinadev.dogmatix.util.ScrapingConstants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

/**
 * Scrapes Nyaa.si for ROM torrents.
 * Uses the RSS feed (page=rss) filtered to Games/Software category (c=6_2).
 * Produces [IndexedFile] results with magnet URIs for download via libtorrent4j.
 */
class NyaaScraper : SourceScraper {

    override fun canHandle(url: String): Boolean =
        url.startsWith("https://nyaa.si") || url.startsWith("http://nyaa.si")

    override suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType,
        folders: List<String>,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult = withContext(Dispatchers.IO) {
        // Build search query from console name + Nyaa's Games category
        val searchTerms = buildSearchTerms(console)
        scrapeNyaaRss(searchTerms, contentType, onProgress)
    }

    /**
     * Searches Nyaa's RSS feed for game ROMs.
     * Category 6_2 = Games > ROMs
     */
    private suspend fun scrapeNyaaRss(
        searchQuery: String,
        contentType: ContentType,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult {
        onProgress?.invoke("Searching Nyaa for $searchQuery...")

        try {
            val params = listOf(
                "page" to "rss",
                "q" to searchQuery,
                "c" to "6_2",      // Games > ROMs category
                "s" to "seeders",  // Sort by seeders
                "o" to "desc"      // Descending
            )
            val queryString = params.joinToString("&") { "${it.first}=${it.second}" }
            val rssUrl = "$NYAA_BASE?$queryString"

            delay(ScrapingConstants.REQUEST_DELAY_MS)

            val connection = Jsoup.connect(rssUrl)
                .userAgent(ScrapingConstants.USER_AGENT)
                .timeout(ScrapingConstants.CONNECTION_TIMEOUT_MS.toInt())
            HttpHeadersUtils.configureBrowserHeaders(connection)
            val doc = connection.get()

            val items = doc.select("item")
            val files = mutableListOf<IndexedFile>()
            val errors = mutableListOf<String>()

            for (item in items) {
                try {
                    val title = item.select("title").text().trim()
                    if (title.isBlank()) continue

                    val link = item.select("link").text().trim()
                    val guid = item.select("guid").text().trim()
                    val seeders = item.select("seeders").text().toIntOrNull() ?: 0
                    val leechers = item.select("leechers").text().toIntOrNull() ?: 0
                    val size = parseSize(item.select("size").text().trim())

                    // Extract info hash from guid or link for magnet URI
                    val infoHash = extractInfoHash(guid, link)

                    // Build magnet URI
                    val magnet = if (infoHash.isNotBlank()) {
                        "magnet:?xt=urn:btih:$infoHash&dn=${java.net.URLEncoder.encode(title, "UTF-8")}"
                    } else {
                        // Fallback: try to get torrent file URL
                        val torrentUrl = if (link.endsWith(".torrent")) link else ""
                        if (torrentUrl.isEmpty()) continue
                        torrentUrl
                    }

                    val (cleanName, tagStrings) = FileParsingUtils.extractNameAndTags(title.substringBeforeLast('.'))
                    val extension = title.substringAfterLast('.', "")
                        .let { if (it.isEmpty()) "" else ".$it" }

                    files.add(
                        IndexedFile(
                            name = cleanName.ifBlank { title },
                            fileName = title,
                            downloadUrl = magnet,
                            fileSize = size,
                            fileExtension = extension,
                            torrentMagnet = if (infoHash.isNotBlank()) magnet else null,
                            tags = tagStrings + listOf(
                                FileParsingUtils.normalizeTag(contentType.name),
                                "nyaa_seeders:$seeders",
                                "nyaa_leechers:$leechers"
                            )
                        )
                    )
                } catch (e: Exception) {
                    errors.add("Failed to parse Nyaa item: ${e.message}")
                }
            }

            return ScrapeResult(files, errors)
        } catch (e: Exception) {
            return ScrapeResult(emptyList(), listOf("Nyaa RSS fetch failed: ${e.message}"))
        }
    }

    private fun buildSearchTerms(console: Console): String {
        // Use console name or short name as search term
        return console.shortName.ifEmpty { console.name }
    }

    private fun extractInfoHash(guid: String, link: String): String {
        // Nyaa GUIDs often contain the info hash
        val hashRegex = Regex("[A-Fa-f0-9]{40}")
        val fromGuid = hashRegex.find(guid)?.value
        if (fromGuid != null) return fromGuid

        // Try to extract from torrent file link
        val fromLink = hashRegex.find(link)
        return fromLink?.value ?: ""
    }

    private fun parseSize(sizeText: String): Long {
        val match = SIZE_REGEX.find(sizeText) ?: return 0L
        val value = match.groupValues[1].toDoubleOrNull() ?: return 0L
        val unit = match.groupValues[2].uppercase()
        val multiplier = when (unit) {
            "B" -> 1L
            "KB", "KIB" -> 1024L
            "MB", "MIB" -> 1024L * 1024
            "GB", "GIB" -> 1024L * 1024 * 1024
            "TB", "TIB" -> 1024L * 1024 * 1024 * 1024
            else -> 1L
        }
        return (value * multiplier).toLong()
    }

    companion object {
        private const val NYAA_BASE = "https://nyaa.si/"
        private val SIZE_REGEX = Regex("([\\d.]+)\\s*(B|KB|KiB|MB|MiB|GB|GiB|TB|TiB)", RegexOption.IGNORE_CASE)
    }
}
