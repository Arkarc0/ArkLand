package com.cortinadev.dogmatix.data.service

import android.util.Log
import com.cortinadev.dogmatix.data.local.dao.DownloadableFileDao
import com.cortinadev.dogmatix.data.local.entity.DownloadableFileEntity
import com.cortinadev.dogmatix.data.local.entity.FileTagEntity
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Manufacturer
import com.cortinadev.dogmatix.data.model.SourceEndpoint
import com.cortinadev.dogmatix.provider.IndexedFile
import com.cortinadev.dogmatix.provider.ProviderRegistry
import com.cortinadev.dogmatix.provider.ScrapeResult
import com.cortinadev.dogmatix.provider.SourceScraper
import com.cortinadev.dogmatix.util.FileParsingUtils
import com.cortinadev.dogmatix.util.HttpHeadersUtils
import com.cortinadev.dogmatix.util.RommSource
import com.cortinadev.dogmatix.util.ScrapingConstants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "DatabaseScrapingService"

@Singleton
class DatabaseScrapingService @Inject constructor(
    private val downloadableFileDao: DownloadableFileDao,
    private val torrentScrapingService: TorrentScrapingService,
    private val rommScrapingService: RommScrapingService,
    private val providerRegistry: ProviderRegistry
) {

    // ---- HTML scraping (existing, preserved) ----

    private suspend fun makeRequest(url: String): org.jsoup.nodes.Document {
        var lastException: Exception? = null
        repeat(ScrapingConstants.MAX_RETRIES) { attempt ->
            try {
                if (attempt > 0) delay(ScrapingConstants.RETRY_DELAY_MS * attempt)
                val connection = Jsoup.connect(url)
                    .userAgent(ScrapingConstants.USER_AGENT)
                    .timeout(ScrapingConstants.CONNECTION_TIMEOUT_MS.toInt())
                HttpHeadersUtils.configureBrowserHeaders(connection)
                return connection.get()
            } catch (e: Exception) {
                lastException = e
                println("Request attempt ${attempt + 1} failed for $url: ${e.message}")
                if (attempt < ScrapingConstants.MAX_RETRIES - 1) delay(ScrapingConstants.RETRY_DELAY_MS)
            }
        }
        throw lastException ?: Exception("All retry attempts failed")
    }

    suspend fun scrapeAndInsertToDatabase(
        baseUrl: String,
        consoleId: String,
        contentType: ContentType = ContentType.GAME,
        visitedUrls: MutableSet<String> = mutableSetOf(),
        rootUrl: String = baseUrl,
        providerId: String = ""
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val allFiles = mutableListOf<DownloadableFileEntity>()
        val allTags = mutableListOf<Pair<DownloadableFileEntity, List<FileTagEntity>>>()

        if (visitedUrls.contains(baseUrl)) return@withContext Pair(0, 0)
        if (!baseUrl.startsWith(rootUrl)) return@withContext Pair(0, 0)
        visitedUrls.add(baseUrl)

        delay(ScrapingConstants.REQUEST_DELAY_MS)
        val doc = makeRequest(baseUrl)
        val table = doc.select(ScrapingConstants.TABLE_SELECTOR).first()
            ?: throw Exception("Could not find file table at $baseUrl. The source might be down (like Myrient) or its structure has changed.")

        for (row in table.select("tr")) {
            val linkCell = row.select("td.link a").first() ?: row.select("a").first() ?: continue
            val href = linkCell.attr("href")
            val linkText = linkCell.text().trim()

            if (href == ScrapingConstants.PARENT_DIRECTORY ||
                href == ScrapingConstants.CURRENT_DIRECTORY ||
                linkText == "Parent directory/" ||
                linkText == "./" || linkText == "../") continue

            if (href.endsWith("/")) {
                val subUrl = FileParsingUtils.buildDownloadUrl(baseUrl, href)
                if (subUrl.contains("/../") || subUrl.endsWith("/..")) continue
                if (visitedUrls.contains(subUrl)) continue
                delay(ScrapingConstants.REQUEST_DELAY_MS)
                continue
            }

            val (fileEntity, tagEntities) = FileParsingUtils.parseFileFromRow(row, baseUrl, consoleId)
            if (fileEntity != null) {
                val taggedFile = if (providerId.isNotEmpty()) fileEntity.copy(sourceId = providerId) else fileEntity
                val contentTypeTag = FileTagEntity(
                    fileId = taggedFile.id,
                    tag = FileParsingUtils.normalizeTag(contentType.name)
                )
                allFiles.add(taggedFile)
                allTags.add(taggedFile to (tagEntities + contentTypeTag))
            }
        }

        if (allFiles.isNotEmpty()) {
            val fileIds = downloadableFileDao.insertAll(allFiles)
            val fileIdMap = allFiles.zip(fileIds)
                .associate { (f, id) -> "${f.fileName}|${f.downloadUrl}" to id }
            val updatedTags = allTags.flatMap { (file, tags) ->
                val fileId = fileIdMap["${file.fileName}|${file.downloadUrl}"] ?: 0L
                tags.map { it.copy(fileId = fileId) }
            }
            downloadableFileDao.insertTags(updatedTags)
        }

        Pair(allFiles.size, allTags.sumOf { it.second.size })
    }

    // ---- Provider-registry routing ----

    /**
     * Scrape using the ProviderRegistry. Routes each URL to the appropriate scraper,
     * converts IndexedFile results to DownloadableFileEntity with sourceId, and inserts.
     */
    suspend fun scrapeWithProviderRegistry(
        endpoints: List<SourceEndpoint>,
        console: Console,
        onProgress: ((String) -> Unit)? = null,
        onScrapeError: (String) -> Unit = {}
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var totalFiles = 0
        var totalTags = 0

        for (endpoint in endpoints) {
            if (!endpoint.enabled) continue

            val scraper = providerRegistry.findScraper(endpoint.url)
            if (scraper == null) {
                onScrapeError("No scraper found for ${endpoint.url}")
                continue
            }

            try {
                val result = scraper.scrape(
                    url = endpoint.url,
                    console = console,
                    contentType = endpoint.contentType,
                    folders = endpoint.folders,
                    onProgress = onProgress
                )
                val (files, tags) = insertIndexedFiles(result, console.id, endpoint.providerId)
                totalFiles += files
                totalTags += tags
            } catch (e: Exception) {
                onScrapeError("Failed to scrape ${endpoint.providerId} for ${console.name}: ${e.message}")
            }
        }

        Pair(totalFiles, totalTags)
    }

    /**
     * Convert [IndexedFile] results to [DownloadableFileEntity] with sourceId and insert into Room.
     * This is the bridge between the provider abstraction layer and the existing database.
     */
    suspend fun insertIndexedFiles(
        result: ScrapeResult,
        consoleId: String,
        providerId: String
    ): Pair<Int, Int> = withContext(Dispatchers.IO) {
        if (result.files.isEmpty()) return@withContext Pair(0, 0)

        val allFiles = mutableListOf<DownloadableFileEntity>()
        val allTags = mutableListOf<Pair<DownloadableFileEntity, List<FileTagEntity>>>()

        for (indexedFile in result.files) {
            val entity = DownloadableFileEntity(
                name = indexedFile.name,
                fileName = indexedFile.fileName,
                consoleId = consoleId,
                downloadUrl = indexedFile.downloadUrl,
                fileSize = indexedFile.fileSize,
                fileExtension = indexedFile.fileExtension,
                torrentFileIndex = indexedFile.torrentFileIndex,
                torrentMagnet = indexedFile.torrentMagnet,
                sourceId = providerId
            )
            allFiles.add(entity)
            val tagEntities = indexedFile.tags.map { tag ->
                FileTagEntity(fileId = 0L, tag = tag)
            }
            allTags.add(entity to tagEntities)
        }

        if (allFiles.isNotEmpty()) {
            val fileIds = downloadableFileDao.insertAll(allFiles)
            val fileIdMap = allFiles.zip(fileIds)
                .associate { (f, id) -> "${f.fileName}|${f.downloadUrl}" to id }
            val updatedTags = allTags.flatMap { (file, tags) ->
                val fileId = fileIdMap["${file.fileName}|${file.downloadUrl}"] ?: 0L
                tags.map { it.copy(fileId = fileId) }
            }
            downloadableFileDao.insertTags(updatedTags)
        }

        Log.d(TAG, "Inserted ${allFiles.size} files from provider $providerId for console $consoleId")
        Pair(allFiles.size, allTags.sumOf { it.second.size })
    }

    // ---- Existing manufacturer scraping (preserved, now with provider attribution) ----

    /**
     * Routes each URL entry to the right scraper.
     * Phase 1: preserves the existing hard-coded routing.
     * When SourceEndpoints are available, prefer [scrapeWithProviderRegistry].
     */
    suspend fun scrapeManufacturer(manufacturer: Manufacturer, onScrapeError: (String) -> Unit = {}): Pair<Int, Int> =
        withContext(Dispatchers.IO) {
            var totalFiles = 0
            var totalTags = 0
            manufacturer.consoles.forEach { console ->
                // Prefer provider-registry routing when endpoints are available
                if (console.endpoints.isNotEmpty()) {
                    val (files, tags) = scrapeWithProviderRegistry(console.endpoints, console, onScrapeError = onScrapeError)
                    totalFiles += files
                    totalTags += tags
                } else {
                    // Fallback to legacy URL-based routing
                    console.urls.filter { it.enabled }.forEach { urlEntry ->
                        try {
                            val providerId = ProviderRegistry.inferProviderId(urlEntry.url)
                            val (files, tags) = if (urlEntry.url.startsWith("magnet:") || urlEntry.url.endsWith(".torrent")) {
                                torrentScrapingService.scrapeAndInsert(urlEntry, console)
                            } else if (RommSource.isSource(urlEntry.url)) {
                                rommScrapingService.scrapeAndInsert(urlEntry, console)
                            } else {
                                scrapeAndInsertToDatabase(urlEntry.url, console.id, urlEntry.contentType, providerId = providerId)
                            }
                            totalFiles += files
                            totalTags += tags
                        } catch (e: Exception) {
                            onScrapeError("Failed to scrape ${console.name}: ${e.message}")
                        }
                    }
                }
            }
            Pair(totalFiles, totalTags)
        }

    suspend fun clearAllData() = downloadableFileDao.clearAll()

    suspend fun clearConsoleData(consoleId: String) = downloadableFileDao.deleteFilesByConsoleId(consoleId)
}
