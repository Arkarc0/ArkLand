package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.util.SearchNormalizer
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Conservative cross-provider deduplication.
 *
 * Groups results by:
 * 1. Content hash (md5/sha1 tags from Internet Archive) — strongest match
 * 2. Normalized filename + size — strong match
 *
 * Different regional/language/revision releases are NOT merged (their filenames differ).
 * A duplicate becomes one logical result with multiple source entries.
 */
@Singleton
class DeduplicationService @Inject constructor() {

    /**
     * Deduplicate a list of indexed files from potentially multiple providers.
     * Returns merged results where each result may have multiple source entries.
     */
    fun deduplicate(files: List<IndexedFile>): List<MergedResult> =
        deduplicate(files, emptyMap())

    /**
     * Deduplicate with provider-priority ordering.
     * [providerPriority] maps providerId → lower = preferred. Sources are ordered
     * by priority so the frontmost source is the default download choice.
     */
    fun deduplicate(files: List<IndexedFile>, providerPriority: Map<String, Int>): List<MergedResult> {
        val buckets = mutableMapOf<String, MergedResult>()

        for (file in files) {
            val key = mergeKey(file)
            val existing = buckets[key]
            if (existing == null) {
                buckets[key] = MergedResult(
                    primary = file,
                    sources = mutableListOf(SourceEntry(
                        providerId = file.tags.firstOrNull { it.startsWith("provider:") }?.removePrefix("provider:") ?: "unknown",
                        file = file
                    ))
                )
            } else {
                // Check if this is a genuinely different source (not a duplicate within same provider)
                val isDifferentSource = existing.sources.none {
                    it.providerId == (file.tags.firstOrNull { it.startsWith("provider:") }?.removePrefix("provider:") ?: "unknown") &&
                    it.file.fileName == file.fileName
                }
                if (isDifferentSource) {
                    existing.sources.add(SourceEntry(
                        providerId = file.tags.firstOrNull { it.startsWith("provider:") }?.removePrefix("provider:") ?: "unknown",
                        file = file
                    ))
                }
            }
        }

        return buckets.values.map { result ->
            result.sources.sortWith(compareBy(
                { providerPriority[it.providerId] ?: Int.MAX_VALUE },
                { it.providerId }
            ))
            result
        }
    }

    /**
     * Generate a merge key for conservative deduplication.
     * Uses the strongest available identifier.
     */
    private fun mergeKey(file: IndexedFile): String {
        // 1. Hash-based match (strongest) — look for tags like md5:<hash> or sha1:<hash>
        val hashTag = file.tags.firstOrNull { it.startsWith("md5:") || it.startsWith("sha1:") }
        if (hashTag != null) return "hash:$hashTag"

        // 2. Normalized filename + size (strong match)
        val normalizedName = SearchNormalizer.key(file.fileName)
        return "$normalizedName:${file.fileSize}"
    }
}

/**
 * A merged result representing one logical ROM with potentially multiple source entries.
 */
data class MergedResult(
    val primary: IndexedFile,
    val sources: MutableList<SourceEntry>
) {
    val sourceCount: Int get() = sources.size
    val providerIds: List<String> get() = sources.map { it.providerId }.distinct()
}

data class SourceEntry(
    val providerId: String,
    val file: IndexedFile
)
