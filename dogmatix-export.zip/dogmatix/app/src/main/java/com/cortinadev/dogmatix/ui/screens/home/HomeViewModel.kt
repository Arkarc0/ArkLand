package com.cortinadev.dogmatix.ui.screens.home

import android.content.Context
import com.cortinadev.dogmatix.R
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cortinadev.dogmatix.data.local.entity.ConsoleEntity
import com.cortinadev.dogmatix.data.local.dao.ConsoleWithFileCount
import com.cortinadev.dogmatix.data.model.DownloadableFileWithTags
import com.cortinadev.dogmatix.data.model.CategorizedTags
import com.cortinadev.dogmatix.data.model.SourceFilter
import com.cortinadev.dogmatix.data.repository.ConsoleRepository
import com.cortinadev.dogmatix.data.repository.SourcesRepository
import com.cortinadev.dogmatix.data.repository.DownloadableFileRepository
import com.cortinadev.dogmatix.data.repository.FavouritesRepository
import com.cortinadev.dogmatix.data.repository.SettingsRepository
import com.cortinadev.dogmatix.data.service.LibraryIndexService
import com.cortinadev.dogmatix.data.local.entity.DownloadableFileEntity
import com.cortinadev.dogmatix.data.service.DownloadService
import com.cortinadev.dogmatix.data.service.GameMetadataService
import com.cortinadev.dogmatix.data.model.GameDetails
import com.cortinadev.dogmatix.provider.DeduplicationService
import com.cortinadev.dogmatix.provider.LiveSearchService
import com.cortinadev.dogmatix.provider.MergedResult
import com.cortinadev.dogmatix.provider.IndexedFile
import com.cortinadev.dogmatix.provider.ProviderSearchResult
import com.cortinadev.dogmatix.provider.ProviderRegistry
import kotlinx.coroutines.Job
import com.cortinadev.dogmatix.data.state.LibraryFilterRequest
import com.cortinadev.dogmatix.data.state.PendingLibraryFilters
import com.cortinadev.dogmatix.data.state.RescanStateHolder
import com.cortinadev.dogmatix.util.ConsoleFormatter
import com.cortinadev.dogmatix.util.DeepLinkResolver
import com.cortinadev.dogmatix.util.StorageHelper
import com.cortinadev.dogmatix.util.ToastUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject

private const val RESOLVE_TIMEOUT_MS = 5_000L

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: DownloadableFileRepository,
    private val sourcesRepository: SourcesRepository,
    private val downloadService: DownloadService,
    private val settingsRepository: SettingsRepository,
    private val rescanStateHolder: RescanStateHolder,
    private val libraryIndex: LibraryIndexService,
    private val metadataService: GameMetadataService,
    private val favourites: FavouritesRepository,
    private val pendingFilters: PendingLibraryFilters,
    private val consoleRepository: ConsoleRepository,
    private val liveSearchService: LiveSearchService,
    private val deduplicationService: DeduplicationService
) : ViewModel() {

    val favouriteKeys: StateFlow<Set<String>> = favourites.keys

    fun isFavourite(file: DownloadableFileEntity, keys: Set<String>): Boolean = favourites.isFavourite(file, keys)

    suspend fun toggleFavourite(item: DownloadableFileWithTags): Boolean = favourites.toggle(item.file)

    private val _favouritesOnly = MutableStateFlow(false)
    val favouritesOnly: StateFlow<Boolean> = _favouritesOnly.asStateFlow()

    fun setFavouritesOnly(only: Boolean) { _favouritesOnly.value = only }

    private val _source = MutableStateFlow(SourceFilter.ALL)
    val source: StateFlow<SourceFilter> = _source.asStateFlow()

    fun setSource(source: SourceFilter) { _source.value = source }

    private val _details = MutableStateFlow<DetailsState?>(null)
    val details: StateFlow<DetailsState?> = _details.asStateFlow()
    private var detailsJob: Job? = null

    fun openDetails(item: DownloadableFileWithTags) {
        detailsJob?.cancel()
        _details.value = DetailsState(item, loading = true)
        detailsJob = viewModelScope.launch {
            val found = metadataService.lookup(item.file.name, item.file.consoleId)
            if (_details.value?.item == item) _details.value = DetailsState(item, loading = false, details = found)
        }
    }

    fun closeDetails() { detailsJob?.cancel(); _details.value = null }

    val ownedKeys: StateFlow<Set<String>> = libraryIndex.ownedKeys

    fun isOwned(file: DownloadableFileEntity, keys: Set<String>): Boolean = libraryIndex.isOwned(file, keys)

    val activeDownloads: StateFlow<Set<String>> = downloadService.downloads
        .map { list -> list.filter { !it.isFinished }.map { it.fileName }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    fun isDownloading(file: DownloadableFileEntity, active: Set<String>): Boolean = file.fileName in active

    suspend fun deleteOwned(fileWithTags: DownloadableFileWithTags): Boolean = libraryIndex.deleteOwned(fileWithTags.file)

    private val _selectedConsoles = MutableStateFlow<Set<String>>(emptySet())
    val selectedConsoles: StateFlow<Set<String>> = _selectedConsoles

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeTags = MutableStateFlow<Set<String>>(emptySet())
    val activeTags: StateFlow<Set<String>> = _activeTags.asStateFlow()

    private val _sortAsc = MutableStateFlow(true)
    val sortAsc: StateFlow<Boolean> = _sortAsc.asStateFlow()

    private val _results = MutableStateFlow<List<DownloadableFileWithTags>>(emptyList())
    val results: StateFlow<List<DownloadableFileWithTags>> = _results

    // ---- Provider search state ----

    /** Live results from provider search, keyed by consoleId. */
    private val _providerResults = MutableStateFlow<List<DownloadableFileWithTags>>(emptyList())
    val providerResults: StateFlow<List<DownloadableFileWithTags>> = _providerResults.asStateFlow()

    /** Status of each provider after a search. */
    private val _providerStatuses = MutableStateFlow<List<ProviderSearchResult>>(emptyList())
    val providerStatuses: StateFlow<List<ProviderSearchResult>> = _providerStatuses.asStateFlow()

    /** Whether a provider search is currently in progress. */
    private val _providerSearchLoading = MutableStateFlow(false)
    val providerSearchLoading: StateFlow<Boolean> = _providerSearchLoading.asStateFlow()

    /** Deduplicated provider results with multi-source info. Keyed by normalized name+size. */
    private val _mergedProviderResults = MutableStateFlow<List<MergedResult>>(emptyList())
    val mergedProviderResults: StateFlow<List<MergedResult>> = _mergedProviderResults.asStateFlow()

    private var providerSearchJob: Job? = null

    // ---- Existing state ----

    private val _consoles = MutableStateFlow<List<ConsoleEntity>>(emptySet())
    val consoles: StateFlow<List<ConsoleEntity>> = _consoles

    private val _consolesWithFiles = MutableStateFlow<List<ConsoleWithFileCount>>(emptySet())
    val consolesWithFiles: StateFlow<List<ConsoleWithFileCount>> = _consolesWithFiles

    private val _categorizedTags = MutableStateFlow<CategorizedTags?>(null)
    val categorizedTags: StateFlow<CategorizedTags?> = _categorizedTags

    val favoriteLanguages: StateFlow<Set<String>> = settingsRepository.favoriteLanguages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val _hasMoreResults = MutableStateFlow(true)
    val hasMoreResults: StateFlow<Boolean> = _hasMoreResults

    private val _isLoadingMore = MutableStateFlow(false)
    val isLoadingMore: StateFlow<Boolean> = _isLoadingMore

    private var currentOffset = 0
    private val pageSize = 100

    init {
        viewModelScope.launch {
            pendingFilters.request.collect { if (it != null) pendingFilters.consume()?.let { request -> applyRequest(request) } }
        }
        viewModelScope.launch {
            combine(
                combine(_searchQuery, _selectedConsoles, _activeTags) { q, c, t -> Triple(q, c, t) },
                combine(_sortAsc, _favouritesOnly, _source, rescanStateHolder.lastRescanTime) { s, f, src, _ -> Triple(s, f, src) },
                combine(_favouritesOnly, favourites.keys) { only, keys -> if (only) keys else emptySet() }.distinctUntilChanged()
            ) { (query, consoles, tags), (sortAsc, favouritesOnly, source), _ ->
                FilterParams(query = query, consoles = consoles, tags = tags, sortAsc = sortAsc, favouritesOnly = favouritesOnly, source = source)
            }.collect { params ->
                currentOffset = 0
                val initialResults = performSearch(params)
                _results.value = initialResults
                _hasMoreResults.value = initialResults.size >= pageSize
                loadConsoles()
                loadAvailableTags(params.query, params.consoles)

                // Trigger provider search for each selected console (non-blocking)
                triggerProviderSearch(params)
            }
        }
    }

    /**
     * Search live providers for the given filter parameters.
     * Runs in parallel with Room search; failures are isolated per provider.
     */
    private fun triggerProviderSearch(params: FilterParams) {
        providerSearchJob?.cancel()
        if (params.query.isBlank() || params.query.length < 2) {
            _providerResults.value = emptyList()
            _providerStatuses.value = emptyList()
            return
        }

        providerSearchJob = viewModelScope.launch {
            _providerSearchLoading.value = true
            try {
                val allProviderFiles = mutableListOf<DownloadableFileWithTags>()
                val allStatuses = mutableListOf<ProviderSearchResult>()

                // Search each selected console's providers
                val consolesToSearch = if (params.consoles.isEmpty()) {
                    // No console filter: search all consoles that have providers
                    _consoles.value.map { it.id }
                } else {
                    params.consoles.toList()
                }

                for (consoleId in consolesToSearch) {
                    val consoleEntity = _consoles.value.find { it.id == consoleId } ?: continue
                    // Build a Console model with endpoints from the entity
                    val console = sourcesRepository.getConsole(consoleId) ?: continue

                    try {
                        val providerResults = liveSearchService.searchProviders(
                            consoleId = consoleId,
                            console = console,
                            query = params.query
                        )
                        for (result in providerResults) {
                            allStatuses.add(result)
                            // Convert IndexedFile to DownloadableFileWithTags for display
                            for (indexedFile in result.files) {
                                val entity = indexedFileToEntity(indexedFile, consoleId, result.providerId)
                                val tags = indexedFile.tags.filter { !it.startsWith("provider:") }
                                allProviderFiles.add(DownloadableFileWithTags(file = entity, tags = tags))
                            }
                        }
                    } catch (_: Exception) {
                        // Provider search for this console failed; continue with others
                    }
                }

                _providerResults.value = allProviderFiles
                _providerStatuses.value = allStatuses
                // Deduplicate across providers
                _mergedProviderResults.value = deduplicationService.deduplicate(
                    allProviderFiles.map { it.file.run {
                        IndexedFile(
                            name = name, fileName = fileName, downloadUrl = downloadUrl,
                            fileSize = fileSize, fileExtension = fileExtension,
                            torrentFileIndex = torrentFileIndex, torrentMagnet = torrentMagnet,
                            tags = it.tags + "provider:${sourceId}"
                        )
                    }}
                )
            } finally {
                _providerSearchLoading.value = false
            }
        }
    }

    /**
     * Convert an [IndexedFile] from a provider into a [DownloadableFileEntity] that the
     * existing UI can display via [RomRow]. The entity is temporary (not persisted to Room)
     * and carries the provider's [sourceId].
     */
    private fun indexedFileToEntity(
        indexedFile: IndexedFile,
        consoleId: String,
        providerId: String
    ): DownloadableFileEntity {
        return DownloadableFileEntity(
            id = 0,
            name = indexedFile.name,
            fileName = indexedFile.fileName,
            consoleId = consoleId,
            downloadUrl = indexedFile.downloadUrl,
            fileSize = indexedFile.fileSize,
            fileExtension = indexedFile.fileExtension,
            torrentFileIndex = indexedFile.torrentFileIndex,
            torrentMagnet = indexedFile.torrentMagnet,
            searchKey = com.cortinadev.dogmatix.util.SearchNormalizer.key(indexedFile.name),
            sourceId = providerId
        )
    }

    // ---- Existing methods (preserved) ----

    private suspend fun applyRequest(request: LibraryFilterRequest) {
        val consoleIds = if (request.consoles.isEmpty()) emptySet() else {
            val consoles = withTimeoutOrNull(RESOLVE_TIMEOUT_MS) { _consoles.first { it.isNotEmpty() } } ?: _consoles.value
            DeepLinkResolver.resolveConsoles(request.consoles, consoles.map { it.id })
        }
        val tags = if (request.tags.isEmpty()) emptySet() else {
            val catalogue = withTimeoutOrNull(RESOLVE_TIMEOUT_MS) { _categorizedTags.first { it != null } } ?: _categorizedTags.value
            val known = catalogue?.let { it.regions.tags + it.languages.tags + it.videoStandards.tags + it.contentTypes.tags + it.fileTypes.tags }.orEmpty()
            DeepLinkResolver.resolveTags(request.tags, known)
        }
        _selectedConsoles.value = consoleIds
        _activeTags.value = tags
        _searchQuery.value = request.query.orEmpty()
        request.favouritesOnly?.let { _favouritesOnly.value = it }
    }

    fun toggleConsoleFilter(consoleId: String) {
        val current = _selectedConsoles.value.toMutableSet()
        if (current.contains(consoleId)) current.remove(consoleId) else current.add(consoleId)
        _selectedConsoles.value = current
    }

    fun clearConsoleFilters() { _selectedConsoles.value = emptySet() }

    fun setSearch(query: String) { _searchQuery.value = query }

    fun toggleTag(tag: String) {
        val current = _activeTags.value.toMutableSet()
        if (current.contains(tag)) current.remove(tag) else current.add(tag)
        _activeTags.value = current
    }

    fun removeTag(tag: String) { _activeTags.value = _activeTags.value - tag }

    fun removeConsole(consoleId: String) { _selectedConsoles.value = _selectedConsoles.value - consoleId }

    fun setSortAsc(ascending: Boolean) { _sortAsc.value = ascending }

    fun setTagsInCategory(categoryTags: Collection<String>, selection: Set<String>) {
        _activeTags.value = (_activeTags.value - categoryTags.toSet()) + selection
    }

    fun setConsoleSelection(consoleIds: Set<String>) { _selectedConsoles.value = consoleIds }

    fun clearAllFilters() {
        _searchQuery.value = ""
        _activeTags.value = emptySet()
        _selectedConsoles.value = emptySet()
        _sortAsc.value = true
        _favouritesOnly.value = false
        _source.value = SourceFilter.ALL
    }

    private suspend fun performSearch(params: FilterParams): List<DownloadableFileWithTags> {
        currentOffset = 0
        return repository.searchFilesWithTags(
            query = params.query,
            consoleIds = params.consoles,
            tags = params.tags,
            favouritesOnly = params.favouritesOnly,
            source = params.source,
            sortAsc = params.sortAsc,
            limit = pageSize,
            offset = 0
        )
    }

    private suspend fun loadConsoles() {
        val allConsoles = consoleRepository.getAllConsoles().first()
        _consoles.value = allConsoles.sortedBy { ConsoleFormatter.getConsoleDisplayName(it.id) }
        val consolesWithFiles = repository.getConsolesWithFiles(
            query = _searchQuery.value.ifBlank { "*" },
            manufacturer = null
        )
        _consolesWithFiles.value = consolesWithFiles.sortedBy { ConsoleFormatter.getConsoleDisplayName(it.id) }
    }

    private suspend fun loadAvailableTags(query: String, consoleIds: Set<String>) {
        _categorizedTags.value = repository.getCategorizedTags(query = query, consoleIds = consoleIds)
    }

    fun getConsoleName(consoleId: String): String = ConsoleFormatter.formatConsoleField(consoleId)

    suspend fun loadMore() {
        if (_isLoadingMore.value || !_hasMoreResults.value) return
        _isLoadingMore.value = true
        currentOffset += pageSize
        val newResults = repository.searchFilesWithTags(
            query = _searchQuery.value,
            consoleIds = _selectedConsoles.value,
            tags = _activeTags.value,
            favouritesOnly = _favouritesOnly.value,
            source = _source.value,
            sortAsc = _sortAsc.value,
            limit = pageSize,
            offset = currentOffset
        )
        if (newResults.isEmpty()) _hasMoreResults.value = false
        else {
            _results.value += newResults
            if (newResults.size < pageSize) _hasMoreResults.value = false
        }
        _isLoadingMore.value = false
    }

    suspend fun startDownload(fileWithTags: DownloadableFileWithTags, context: Context) {
        val downloadDirectory = settingsRepository.downloadDirectory.first()
        if (downloadDirectory.isEmpty()) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_missing))
            return
        }
        if (!StorageHelper.isValidUri(context, downloadDirectory)) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_inaccessible))
            return
        }
        downloadService.startDownload(fileWithTags.file)
    }

    /**
     * Start a download for a specific source from a merged result.
     * The user has selected which provider source to download from.
     */
    suspend fun startSourceDownload(source: com.cortinadev.dogmatix.provider.SourceEntry, consoleId: String, context: Context) {
        val downloadDirectory = settingsRepository.downloadDirectory.first()
        if (downloadDirectory.isEmpty()) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_missing))
            return
        }
        if (!StorageHelper.isValidUri(context, downloadDirectory)) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_inaccessible))
            return
        }
        val file = source.file
        val entity = DownloadableFileEntity(
            id = 0, name = file.name, fileName = file.fileName,
            consoleId = consoleId, downloadUrl = file.downloadUrl,
            fileSize = file.fileSize, fileExtension = file.fileExtension,
            torrentFileIndex = file.torrentFileIndex, torrentMagnet = file.torrentMagnet,
            searchKey = com.cortinadev.dogmatix.util.SearchNormalizer.key(file.name),
            sourceId = source.providerId
        )
        downloadService.startDownload(entity)
    }

    /**
     * Start a download for a provider result (not yet indexed in Room).
     * The entity is created on-the-fly from the provider's IndexedFile data.
     */
    suspend fun startProviderDownload(fileWithTags: DownloadableFileWithTags, context: Context) {
        val downloadDirectory = settingsRepository.downloadDirectory.first()
        if (downloadDirectory.isEmpty()) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_missing))
            return
        }
        if (!StorageHelper.isValidUri(context, downloadDirectory)) {
            ToastUtil.showError(context, context.getString(R.string.error_download_dir_inaccessible))
            return
        }
        downloadService.startDownload(fileWithTags.file)
    }
}

data class FilterParams(
    val query: String,
    val consoles: Set<String>,
    val tags: Set<String>,
    val sortAsc: Boolean,
    val favouritesOnly: Boolean = false,
    val source: SourceFilter = SourceFilter.ALL
)

data class DetailsState(
    val item: DownloadableFileWithTags,
    val loading: Boolean,
    val details: GameDetails? = null
)
