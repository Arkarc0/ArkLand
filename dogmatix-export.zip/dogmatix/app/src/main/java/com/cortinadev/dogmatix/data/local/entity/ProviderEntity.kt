package com.cortinadev.dogmatix.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A ROM source provider (e.g. Myrient, Internet Archive, RomM, Nyaa).
 * Providers are independent of download method: a provider may offer HTTP, torrent, or both.
 */
@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val enabled: Boolean = true,
    val priority: Int = 0
)
