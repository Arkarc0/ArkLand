package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console

/**
 * Interface for provider-specific scraping. Implementations parse a source URL
 * and return normalized [IndexedFile] results. Providers are independent of
 * download method (HTTP/torrent) — that determination happens later in DownloadService.
 */
interface SourceScraper {

    /** Whether this scraper can handle the given URL. */
    fun canHandle(url: String): Boolean

    /**
     * Scrape a source URL and return indexed files.
     *
     * @param url The source URL to scrape.
     * @param console The console this source belongs to.
     * @param contentType The content type (GAME, MISCELLANEOUS, etc.).
     * @param folders Optional folder filter (for torrent sources).
     * @param onProgress Optional progress callback for long-running operations.
     * @return Pair of (files indexed, tags created).
     */
    suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType = ContentType.GAME,
        folders: List<String> = emptyList(),
        onProgress: ((String) -> Unit)? = null
    ): ScrapeResult
}

data class ScrapeResult(
    val files: List<IndexedFile>,
    val errors: List<String> = emptyList()
)
