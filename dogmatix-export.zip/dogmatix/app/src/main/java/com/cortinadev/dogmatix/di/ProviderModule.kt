package com.cortinadev.dogmatix.di

import com.cortinadev.dogmatix.data.service.TorrentFileIndexer
import com.cortinadev.dogmatix.data.service.TorrentMetadataFetcher
import com.cortinadev.dogmatix.data.service.RommClient
import com.cortinadev.dogmatix.provider.ArchiveScraper
import com.cortinadev.dogmatix.provider.HtmlDirectoryScraper
import com.cortinadev.dogmatix.provider.NyaaScraper
import com.cortinadev.dogmatix.provider.ProviderRegistry
import com.cortinadev.dogmatix.provider.RommApiScraper
import com.cortinadev.dogmatix.provider.TorrentSourceScraper
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Registers all provider scrapers with the [ProviderRegistry].
 * Scrapers are registered in priority order (most specific first).
 */
@Module
@InstallIn(SingletonComponent::class)
object ProviderModule {

    @Provides
    @Singleton
    fun provideProviderRegistry(
        rommClient: RommClient,
        torrentMetadataFetcher: TorrentMetadataFetcher,
        torrentFileIndexer: TorrentFileIndexer
    ): ProviderRegistry {
        val registry = ProviderRegistry()

        // Register scrapers in priority order (most specific first)
        // 1. Nyaa (torrent RSS) — must check before generic HTTP
        registry.register(NyaaScraper())

        // 2. RomM (API) — scheme-based, won't conflict
        registry.register(RommApiScraper(rommClient))

        // 3. Torrent (magnet/.torrent) — must check before generic HTTP
        registry.register(TorrentSourceScraper(torrentMetadataFetcher, torrentFileIndexer))

        // 4. Archive (API) — domain-based, won't conflict with generic HTML
        registry.register(ArchiveScraper())

        // 5. HTML directory (generic) — catch-all for HTTP URLs
        registry.register(HtmlDirectoryScraper())

        return registry
    }
}
