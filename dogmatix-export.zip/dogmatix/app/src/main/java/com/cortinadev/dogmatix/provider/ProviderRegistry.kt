package com.cortinadev.dogmatix.provider

import android.util.Log
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "ProviderRegistry"

/**
 * Routes URL scraping to the appropriate [SourceScraper] based on URL pattern.
 * Replaces the hard-coded if/else chain in DatabaseScrapingService.
 *
 * Registered scrapers are checked in order; the first one that [SourceScraper.canHandle]
 * returns true for wins.
 */
@Singleton
class ProviderRegistry @Inject constructor() {

    private val scrapers = mutableListOf<SourceScraper>()

    fun register(scraper: SourceScraper) {
        scrapers.add(scraper)
        Log.d(TAG, "Registered scraper: ${scraper.javaClass.simpleName} (canHandle examples checked)")
    }

    /** Find the first scraper that can handle this URL, or null. */
    fun findScraper(url: String): SourceScraper? =
        scrapers.firstOrNull { it.canHandle(url) }

    /** Check if any registered scraper can handle this URL. */
    fun canHandle(url: String): Boolean =
        scrapers.any { it.canHandle(url) }

    /** All registered scrapers (for inspection/debugging). */
    fun registeredScrapers(): List<SourceScraper> = scrapers.toList()

    companion object {
        /** Provider IDs for well-known providers. */
        const val PROVIDER_MYRIENT = "myrient"
        const val PROVIDER_ARCHIVE = "archive"
        const val PROVIDER_ROMM = "romm"
        const val PROVIDER_NYAA = "nyaa"
        const val PROVIDER_HTML = "html"
        const val PROVIDER_TORRENT = "torrent"

        /**
         * Infer a provider ID from a URL, matching the same logic the existing code uses.
         */
        fun inferProviderId(url: String): String = when {
            url.contains("nyaa.si") -> PROVIDER_NYAA
            url.contains("archive.org") -> PROVIDER_ARCHIVE
            url.contains("myrient.erista.me") || url.contains("minerva-archive.org") -> PROVIDER_MYRIENT
            url.startsWith("romm://") -> PROVIDER_ROMM
            url.startsWith("magnet:") || url.endsWith(".torrent") -> PROVIDER_TORRENT
            else -> PROVIDER_HTML
        }

        fun providerName(id: String): String = when (id) {
            PROVIDER_MYRIENT -> "Myrient"
            PROVIDER_ARCHIVE -> "Internet Archive"
            PROVIDER_ROMM -> "RomM"
            PROVIDER_NYAA -> "Nyaa"
            PROVIDER_TORRENT -> "Torrent"
            PROVIDER_HTML -> "HTML Source"
            else -> id.replaceFirstChar { it.uppercase() }
        }

        fun providerType(id: String): String = when (id) {
            PROVIDER_MYRIENT -> "html_directory"
            PROVIDER_ARCHIVE -> "api"
            PROVIDER_ROMM -> "api"
            PROVIDER_NYAA -> "torrent_rss"
            PROVIDER_TORRENT -> "torrent"
            PROVIDER_HTML -> "html_directory"
            else -> "html_directory"
        }
    }
}
