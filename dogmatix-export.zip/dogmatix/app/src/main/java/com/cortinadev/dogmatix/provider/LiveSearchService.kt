package com.cortinadev.dogmatix.provider

import android.util.Log
import com.cortinadev.dogmatix.data.local.dao.ProviderDao
import com.cortinadev.dogmatix.data.local.dao.SourceEndpointDao
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.data.model.ContentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

private const val TAG = "LiveSearchService"
private const val PROVIDER_TIMEOUT_MS = 15_000L

/**
 * Lightweight service that queries enabled providers for a specific console.
 * Used by HomeViewModel to augment local Room search with live provider results.
 *
 * Unlike [UnifiedSearchService] which deduplicates, this service returns raw results
 * from each provider so the UI can display them alongside local indexed results.
 */
@Singleton
class LiveSearchService @Inject constructor(
    private val providerRegistry: ProviderRegistry,
    private val providerDao: ProviderDao,
    private val sourceEndpointDao: SourceEndpointDao
) {
    /**
     * Search all enabled providers that have endpoints for the given console.
     * Returns per-provider results so the UI can show provider attribution.
     */
    suspend fun searchProviders(
        consoleId: String,
        console: Console,
        query: String,
        onProgress: ((String) -> Unit)? = null
    ): List<ProviderSearchResult> = withContext(Dispatchers.IO) {
        val enabledProviders = providerDao.getEnabledProviders()
        if (enabledProviders.isEmpty()) return@withContext emptyList()

        coroutineScope {
            enabledProviders.map { provider ->
                async {
                    searchSingleProvider(provider.id, consoleId, console, onProgress)
                }
            }.awaitAll()
        }
    }

    private suspend fun searchSingleProvider(
        providerId: String,
        consoleId: String,
        console: Console,
        onProgress: ((String) -> Unit)?
    ): ProviderSearchResult {
        val startTime = System.currentTimeMillis()

        try {
            val endpoints = sourceEndpointDao.getEndpointsByProvider(providerId)
                .filter { it.consoleId == consoleId }

            if (endpoints.isEmpty()) {
                return ProviderSearchResult(
                    providerId = providerId,
                    ok = true,
                    count = 0,
                    error = null,
                    tookMs = System.currentTimeMillis() - startTime,
                    files = emptyList()
                )
            }

            val scraper = providerRegistry.findScraper(endpoints.first().url)
                ?: return ProviderSearchResult(
                    providerId = providerId,
                    ok = false,
                    count = 0,
                    error = "No scraper for $providerId",
                    tookMs = System.currentTimeMillis() - startTime,
                    files = emptyList()
                )

            val allFiles = mutableListOf<IndexedFile>()
            for (endpoint in endpoints) {
                if (!endpoint.enabled) continue
                val result = withTimeoutOrNull(PROVIDER_TIMEOUT_MS) {
                    scraper.scrape(
                        url = endpoint.url,
                        console = console,
                        contentType = ContentType.valueOf(endpoint.contentType),
                        folders = emptyList(),
                        onProgress = onProgress
                    )
                } ?: continue
                // Tag files with provider ID
                val taggedFiles = result.files.map { file ->
                    file.copy(tags = file.tags + "provider:$providerId")
                }
                allFiles.addAll(taggedFiles)
            }

            return ProviderSearchResult(
                providerId = providerId,
                ok = true,
                count = allFiles.size,
                error = null,
                tookMs = System.currentTimeMillis() - startTime,
                files = allFiles
            )
        } catch (e: Exception) {
            Log.e(TAG, "Provider $providerId search failed: ${e.message}")
            return ProviderSearchResult(
                providerId = providerId,
                ok = false,
                count = 0,
                error = e.message,
                tookMs = System.currentTimeMillis() - startTime,
                files = emptyList()
            )
        }
    }
}

data class ProviderSearchResult(
    val providerId: String,
    val ok: Boolean,
    val count: Int,
    val error: String?,
    val tookMs: Long,
    val files: List<IndexedFile>
)
