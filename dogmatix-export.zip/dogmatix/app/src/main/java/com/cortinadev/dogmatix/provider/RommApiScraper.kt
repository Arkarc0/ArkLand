package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.data.service.RommClient
import com.cortinadev.dogmatix.util.FileParsingUtils
import com.cortinadev.dogmatix.util.RommSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Scrapes a RomM server via its REST API.
 * Produces [IndexedFile] results for each ROM on the configured platform.
 * Downloads go through RomM's /api/roms/{id}/content/ endpoint with auth headers.
 */
class RommApiScraper(
    private val rommClient: RommClient
) : SourceScraper {

    override fun canHandle(url: String): Boolean =
        RommSource.isSource(url)

    override suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType,
        folders: List<String>,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult = withContext(Dispatchers.IO) {
        val slug = RommSource.slugOf(url)
            ?: return@withContext ScrapeResult(emptyList(), listOf("Invalid RomM source: $url"))

        val base = try {
            rommClient.configuredBaseUrl()
        } catch (e: Exception) {
            return@withContext ScrapeResult(emptyList(), listOf("RomM server not configured: ${e.message}"))
        }
        if (base.isEmpty()) {
            return@withContext ScrapeResult(emptyList(), listOf("RomM server not configured"))
        }

        onProgress?.invoke("Listing $slug on RomM...")

        try {
            val platforms = rommClient.platforms()
            val platform = platforms.firstOrNull {
                it.slug.equals(slug, true) || it.fsSlug.equals(slug, true) || it.id.toString() == slug
            } ?: return@withContext ScrapeResult(emptyList(), listOf("RomM has no platform '$slug'"))

            val roms = rommClient.roms(platform.id)
            if (roms.isEmpty()) {
                return@withContext ScrapeResult(emptyList())
            }

            val files = roms.map { rom ->
                val (cleanName, tagStrings) = FileParsingUtils.extractNameAndTags(
                    rom.fsName.substringBeforeLast('.', rom.fsName)
                )
                val downloadUrl = RommSource.downloadUrl(base, rom.id, rom.fsName)
                val extension = rom.fsName.substringAfterLast('.', "")
                    .let { if (it.isEmpty()) "" else ".$it" }

                IndexedFile(
                    name = cleanName.ifBlank { rom.name.ifBlank { rom.fsName } },
                    fileName = rom.fsName,
                    downloadUrl = downloadUrl,
                    fileSize = rom.fsSizeBytes,
                    fileExtension = extension,
                    tags = tagStrings + listOf(FileParsingUtils.normalizeTag(contentType.name))
                )
            }

            ScrapeResult(files)
        } catch (e: Exception) {
            ScrapeResult(emptyList(), listOf("RomM scrape failed: ${e.message}"))
        }
    }
}
