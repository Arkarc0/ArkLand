package com.cortinadev.dogmatix.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A concrete URL endpoint linking a [ProviderEntity] to a [ConsoleEntity].
 * Multiple endpoints can exist per provider (e.g. Myrient has different URLs per console).
 */
@Entity(
    tableName = "source_endpoints",
    foreignKeys = [
        ForeignKey(
            entity = ProviderEntity::class,
            parentColumns = ["id"],
            childColumns = ["providerId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ConsoleEntity::class,
            parentColumns = ["id"],
            childColumns = ["consoleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("providerId"), Index("consoleId")]
)
data class SourceEndpointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val providerId: String,
    val consoleId: String,
    val url: String,
    val contentType: String = "GAME",
    @ColumnInfo(defaultValue = "[]") val folders: String = "[]",
    val enabled: Boolean = true
)
