package com.cortinadev.dogmatix.provider

import com.cortinadev.dogmatix.data.model.ContentType
import com.cortinadev.dogmatix.data.model.Console
import com.cortinadev.dogmatix.util.FileParsingUtils
import com.cortinadev.dogmatix.util.HttpHeadersUtils
import com.cortinadev.dogmatix.util.ScrapingConstants
import kotlinx.coroutines.delay
import org.jsoup.Jsoup

/**
 * Scrapes HTML directory listings (e.g. Myrient/Minerva, generic HTTP file servers).
 * Parses table-based directory indexes and produces [IndexedFile] results.
 *
 * Reuses the same Jsoup parsing logic from the original DatabaseScrapingService
 * but returns results instead of inserting them directly.
 */
class HtmlDirectoryScraper : SourceScraper {

    override fun canHandle(url: String): Boolean =
        url.startsWith("http://") || url.startsWith("https://")

    override suspend fun scrape(
        url: String,
        console: Console,
        contentType: ContentType,
        folders: List<String>,
        onProgress: ((String) -> Unit)?
    ): ScrapeResult {
        return scrapeDirectory(url, console.id, contentType, onProgress)
    }

    /**
     * Recursively scrapes an HTML directory listing, producing [IndexedFile] results.
     * This is the core parsing logic extracted from DatabaseScrapingService.scrapeAndInsertToDatabase().
     */
    suspend fun scrapeDirectory(
        baseUrl: String,
        consoleId: String,
        contentType: ContentType = ContentType.GAME,
        onProgress: ((String) -> Unit)? = null,
        visitedUrls: MutableSet<String> = mutableSetOf(),
        rootUrl: String = baseUrl
    ): ScrapeResult {
        if (visitedUrls.contains(baseUrl)) return ScrapeResult(emptyList())
        if (!baseUrl.startsWith(rootUrl)) return ScrapeResult(emptyList())
        visitedUrls.add(baseUrl)

        onProgress?.invoke("Scraping $baseUrl")
        delay(ScrapingConstants.REQUEST_DELAY_MS)

        val doc = try {
            makeRequest(baseUrl)
        } catch (e: Exception) {
            return ScrapeResult(emptyList(), listOf("Failed to fetch $baseUrl: ${e.message}"))
        }

        val table = doc.select(ScrapingConstants.TABLE_SELECTOR).first()
            ?: return ScrapeResult(emptyList(), listOf("No file table at $baseUrl"))

        val files = mutableListOf<IndexedFile>()
        val errors = mutableListOf<String>()

        for (row in table.select("tr")) {
            val linkCell = row.select("td.link a").first() ?: row.select("a").first() ?: continue
            val href = linkCell.attr("href")
            val linkText = linkCell.text().trim()

            if (href == ScrapingConstants.PARENT_DIRECTORY ||
                href == ScrapingConstants.CURRENT_DIRECTORY ||
                linkText == "Parent directory/" ||
                linkText == "./" || linkText == "../") continue

            if (href.endsWith("/")) {
                val subUrl = FileParsingUtils.buildDownloadUrl(baseUrl, href)
                if (subUrl.contains("/../") || subUrl.endsWith("/..")) continue
                if (visitedUrls.contains(subUrl)) continue
                // Recurse into subdirectory
                val subResult = scrapeDirectory(subUrl, consoleId, contentType, onProgress, visitedUrls, rootUrl)
                files.addAll(subResult.files)
                errors.addAll(subResult.errors)
                continue
            }

            try {
                val (fileEntity, tagEntities) = FileParsingUtils.parseFileFromRow(row, baseUrl, consoleId)
                if (fileEntity != null) {
                    files.add(
                        IndexedFile(
                            name = fileEntity.name,
                            fileName = fileEntity.fileName,
                            downloadUrl = fileEntity.downloadUrl,
                            fileSize = fileEntity.fileSize,
                            fileExtension = fileEntity.fileExtension,
                            tags = tagEntities.map { it.tag }
                        )
                    )
                }
            } catch (e: Exception) {
                errors.add("Failed to parse row: ${e.message}")
            }
        }

        return ScrapeResult(files, errors)
    }

    private suspend fun makeRequest(url: String): org.jsoup.nodes.Document {
        var lastException: Exception? = null
        repeat(ScrapingConstants.MAX_RETRIES) { attempt ->
            try {
                if (attempt > 0) delay(ScrapingConstants.RETRY_DELAY_MS * attempt)
                val connection = Jsoup.connect(url)
                    .userAgent(ScrapingConstants.USER_AGENT)
                    .timeout(ScrapingConstants.CONNECTION_TIMEOUT_MS.toInt())
                HttpHeadersUtils.configureBrowserHeaders(connection)
                return connection.get()
            } catch (e: Exception) {
                lastException = e
                if (attempt < ScrapingConstants.MAX_RETRIES - 1) delay(ScrapingConstants.RETRY_DELAY_MS)
            }
        }
        throw lastException ?: Exception("All retry attempts failed for $url")
    }
}
