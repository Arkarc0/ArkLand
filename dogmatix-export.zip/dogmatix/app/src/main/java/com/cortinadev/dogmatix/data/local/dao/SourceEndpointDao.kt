package com.cortinadev.dogmatix.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.cortinadev.dogmatix.data.local.entity.SourceEndpointEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SourceEndpointDao {

    @Query("SELECT * FROM source_endpoints")
    fun getAllEndpoints(): Flow<List<SourceEndpointEntity>>

    @Query("SELECT * FROM source_endpoints WHERE consoleId = :consoleId AND enabled = 1")
    suspend fun getEndpointsForConsole(consoleId: String): List<SourceEndpointEntity>

    @Query("SELECT * FROM source_endpoints WHERE consoleId = :consoleId AND enabled = 1")
    fun observeEndpointsForConsole(consoleId: String): Flow<List<SourceEndpointEntity>>

    @Query("SELECT * FROM source_endpoints WHERE providerId = :providerId AND enabled = 1")
    suspend fun getEndpointsByProvider(providerId: String): List<SourceEndpointEntity>

    @Query("SELECT * FROM source_endpoints WHERE providerId = :providerId AND consoleId = :consoleId AND enabled = 1 LIMIT 1")
    suspend fun getEndpoint(providerId: String, consoleId: String): SourceEndpointEntity?

    @Query("SELECT DISTINCT providerId FROM source_endpoints WHERE consoleId = :consoleId AND enabled = 1")
    suspend fun getProviderIdsForConsole(consoleId: String): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEndpoint(endpoint: SourceEndpointEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEndpoints(endpoints: List<SourceEndpointEntity>): List<Long>

    @Query("DELETE FROM source_endpoints WHERE consoleId = :consoleId")
    suspend fun deleteEndpointsForConsole(consoleId: String)

    @Query("DELETE FROM source_endpoints WHERE providerId = :providerId")
    suspend fun deleteEndpointsForProvider(providerId: String)

    @Query("DELETE FROM source_endpoints")
    suspend fun clearAll()
}
