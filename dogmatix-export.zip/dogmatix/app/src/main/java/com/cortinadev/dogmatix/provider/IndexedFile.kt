package com.cortinadev.dogmatix.provider

/**
 * A normalized result from a provider scraper. Provider-independent.
 * Maps directly to [DownloadableFileEntity] fields for persistence.
 */
data class IndexedFile(
    val name: String,
    val fileName: String,
    val downloadUrl: String,
    val fileSize: Long = 0L,
    val fileExtension: String = "",
    val torrentFileIndex: Int? = null,
    val torrentMagnet: String? = null,
    val tags: List<String> = emptyList()
)
