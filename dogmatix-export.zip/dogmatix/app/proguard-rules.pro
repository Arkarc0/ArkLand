# 7-Zip-JBinding — JNI bridge classes must not be renamed or stripped
-keep class net.sf.sevenzipjbinding.** { *; }

# libtorrent4j
-keep class org.libtorrent4j.** { *; }
-keep interface org.libtorrent4j.** { *; }
-keepclassmembers class org.libtorrent4j.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-keepclassmembers class org.libtorrent4j.swig.libtorrent_jni {
    public static void SwigDirector_*(*);
    static void SwigDirector_*(*);
    native <methods>;
}
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod,SourceFile,LineNumberTable
-dontwarn org.libtorrent4j.**

# Jsoup optional dependency on RE2J
-dontwarn com.google.re2j.**

# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile